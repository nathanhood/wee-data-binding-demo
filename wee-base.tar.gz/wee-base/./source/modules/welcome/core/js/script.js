Wee.routes.map({
	'$root': 'todo'
}, true);