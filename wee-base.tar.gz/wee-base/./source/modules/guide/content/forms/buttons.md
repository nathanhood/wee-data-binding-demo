---
name: Buttons
---

---html|render---

<button>Standard</button>
<button class="button-colored">Colored</button>
<button disabled>Disabled</button>