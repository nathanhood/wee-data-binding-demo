---
name: Input fields
---

---html|render---

<input type="email" name="name" placeholder="Email Address" required>

<label for="message">Message</label><textarea name="textarea" id="message" required></textarea>