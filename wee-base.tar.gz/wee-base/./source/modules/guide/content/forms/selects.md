---
name: Select fields
---

---html|render---

<select name="selection">
	<option value="1">Lorem</option>
	<option value="2">Ipsum</option>
	<option value="3">Dolor</option>
</select>

<label for="multi-selection">Multiple Selection</label>
<select name="multi-selection" id="multi-selection" multiple>
	<optgroup label="Grouping">
		<option value="1">Lorem</option>
		<option value="2">Ipsum</option>
		<option value="3">Dolor</option>
	</optgroup>
</select>