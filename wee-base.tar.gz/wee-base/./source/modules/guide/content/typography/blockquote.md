---
name: Blockquote
---

---html|render---

<blockquote>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ullamcorper bibendum nisl, eu aliquam libero luctus in. Cras eleifend, arcu ut varius suscipit, sem purus vehicula tortor, et iaculis ligula magna et magna. Integer et lacus enim.</p>
	<cite><a href="#">John Doe</a></cite>
</blockquote>