---
name: Paragraph
---

---html|render---

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nibh sapien, porttitor non nibh et, sodales cursus est. Cras nec tristique sem. Nam ex nulla, sagittis a facilisis ac, suscipit at justo. Etiam lectus massa, aliquam ornare ligula quis, tempus dictum odio. Duis ac porttitor sapien. Nulla a nibh in libero imperdiet tempor gravida non magna. Nullam pulvinar nibh sit amet blandit iaculis.</p>