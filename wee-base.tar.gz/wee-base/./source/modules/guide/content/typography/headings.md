---
name: Headings
heading: Headings establish a semantic hierarchy of importance
class: headings
---

---html|render---

<h1>Heading <small>.h1</small></h1>
<h2>Heading <small>.h2</small></h2>
<h3>Heading <small>.h3</small></h3>
<h4>Heading <small>.h4</small></h4>
<h5>Heading <small>.h5</small></h5>
<h6>Heading <small>.h6</small></h6>