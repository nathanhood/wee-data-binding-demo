---
name: Address
---

---html|render---

<address itemscope itemtype="http://schema.org/PostalAddress">
	<strong itemprop="name">Company Name</strong><br>
	<span itemprop="streetAddress">123 Main Street</span><br>
	<span itemprop="addressLocality">City</span>, <abbr title="State" itemprop="addressRegion">ST</abbr> <span itemprop="postalCode">12345</span>
</address>