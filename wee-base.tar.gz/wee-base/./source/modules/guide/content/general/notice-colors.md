---
name: Notice colors
heading: These colors are used when displaying various notifications
---

<ol class="swatches">
	<li class="swatch -info">@info</li>
	<li class="swatch -success">@success</li>
	<li class="swatch -warning">@warning</li>
</ol>