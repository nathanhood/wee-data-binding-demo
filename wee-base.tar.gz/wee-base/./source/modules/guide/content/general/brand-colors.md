---
name: Brand colors
heading: Our primary color pallet is used for major UI visuals and controls
---

<ol class="swatches">
	<li class="swatch -primary">@primary</li>
	<li class="swatch -secondary">@secondary</li>
	<li class="swatch -tertiary">@tertiary</li>
</ol>