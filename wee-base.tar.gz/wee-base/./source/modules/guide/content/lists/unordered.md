---
name: Unordered list
heading: Use lists to represent groups of related data
---

---html|render---

<ul>
	<li>Lorem ipsum dolor
		<ul>
			<li>Lorem ipsum dolor
				<ul>
					<li>Lorem ipsum dolor</li>
					<li>Lorem ipsum dolor</li>
				</ul>
			</li>
			<li>Lorem ipsum dolor
				<ol>
					<li>Lorem ipsum dolor</li>
					<li>Lorem ipsum dolor</li>
				</ol>
			</li>
		</ul>
	</li>
	<li>Lorem ipsum dolor</li>
	<li>Lorem ipsum dolor</li>
</ul>