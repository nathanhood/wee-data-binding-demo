---
name: Ordered list
---

---html|render---

<ol>
	<li>Lorem ipsum dolor
		<ol>
			<li>Lorem ipsum dolor
				<ul>
					<li>Lorem ipsum dolor</li>
				</ul>
			</li>
			<li>Lorem ipsum dolor
				<ol>
					<li>Lorem ipsum dolor</li>
					<li>Lorem ipsum dolor</li>
				</ol>
			</li>
		</ol>
	</li>
	<li>Lorem ipsum dolor</li>
	<li>Lorem ipsum dolor</li>
</ol>