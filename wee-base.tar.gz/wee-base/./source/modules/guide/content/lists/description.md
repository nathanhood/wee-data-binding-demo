---
name: Description list
---

---html|render---

<dl>
	<dt>Lorem ipsum dolor</dt>
	<dd>Sit amet, consectetur adipiscing elit.</dd>
	<dt>Lorem ipsum dolor</dt>
	<dd>Sit amet, consectetur adipiscing elit.</dd>
</dl>