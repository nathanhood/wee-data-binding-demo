---
name: Code
---

A <code>&lt;code&gt;</code> element wrapped in a <code>&lt;pre&gt;</code> element is used to generate code example blocks.

---html|render---

<pre><code class="nohighlight">&lt;figure&gt;
	&lt;img src=&quot;//placehold.it/800x400&quot; alt=&quot;Figure Image&quot;&gt;
	&lt;figcaption&gt;&lt;b&gt;Fig. 3.2 |&lt;/b&gt; Lorem ipsum dolor sit amet, consectetur adipisicing elit by &lt;a href=&quot;#&quot;&gt;eiusmod tempor&lt;/a&gt;&lt;/figcaption&gt;
&lt;/figure&gt;</code></pre>