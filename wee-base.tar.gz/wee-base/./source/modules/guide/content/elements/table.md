---
name: Table
---

---html|render---

<div class="responsive-table">
	<table itemscope itemtype="http://schema.org/Table">
		<caption itemprop="about">Caption ipsum dolor sit amet</caption>
		<thead>
			<tr>
				<th>Heading</th>
				<th>Heading</th>
				<th>Heading</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Lorem ipsum dolor</td>
				<td>Lorem ipsum dolor</td>
				<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit</td>
			</tr>
			<tr>
				<td>Lorem ipsum dolor</td>
				<td>Lorem ipsum dolor</td>
				<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit</td>
			</tr>
			<tr>
				<td>Lorem ipsum dolor</td>
				<td>Lorem ipsum dolor</td>
				<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit</td>
			</tr>
		</tbody>
	</table>
</div>