// Add custom view helpers here

// Wee.view.addHelper('upper', function() {
// 	return this.val.toUpperCase();
// });