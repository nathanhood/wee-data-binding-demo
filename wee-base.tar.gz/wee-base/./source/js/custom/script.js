// Add custom JavaScript here
// Route documentation available at https://www.weepower.com/script/routes

Wee.routes.map({
	'$root': 'common'
});

Wee.ready('routes:run');